# AI Godot Assistant プラグイン - インストールガイド

## 📦 このプラグインについて

Godot 4.x用のAIアシスタントプラグインです。Gemini APIを使って、自然言語でゲームシーンを作成できます。

## 🚀 インストール方法

### ステップ1: ファイルのコピー

**このフォルダ全体**を新しいGodotプロジェクトにコピーしてください：

```
addons/ai_godot_assistant/
```

**コピー先**：
```
あなたのGodotプロジェクト/addons/ai_godot_assistant/
```

### ステップ2: プラグインの有効化

1. Godotエディタを開く
2. **プロジェクト → プロジェクト設定 → プラグイン**
3. **「AI Godot Assistant」**にチェックを入れる
4. エディタの右側に**「AI Godot Assistant」パネル**が表示されます

### ステップ3: APIキーの設定

#### 3-1. Gemini APIキーを取得

1. [Google AI Studio](https://aistudio.google.com/app/apikey)にアクセス
2. 「Create API Key」をクリック
3. APIキーをコピー

#### 3-2. 設定ファイルを作成

**方法A: ファイルを手動作成**

1. `addons/ai_godot_assistant/config.cfg.example`を開く
2. 同じフォルダに`config.cfg`として保存
3. `YOUR_API_KEY_HERE`を実際のAPIキーに置き換える

```ini
[api]
gemini_api_key = "AIzaSy..."  # ← ここに実際のAPIキーを貼り付け
selected_model = "gemini-2.5-flash"
```

**方法B: プラグインUI経由で設定**

1. AI Godot Assistantパネルを開く
2. 「Gemini APIキー」欄にAPIキーを貼り付け
3. 自動的に`config.cfg`が作成されます

## ✅ インストール完了の確認

以下が表示されていればOKです：

1. **エディタ右側**に「AI Godot Assistant」パネル
2. パネルに「Gemini APIキー」入力欄
3. AIモデル選択ドロップダウン
4. プロンプト入力エリア

## 🎮 使い方

### 基本的な使い方

1. **シーンを開く**（新規または既存）
2. **AI Godot Assistantパネル**でプロンプトを入力：
   ```
   3Dアスレチックゲームを作成してください
   ```
3. **「送信」**ボタンをクリック
4. AIが自動的にノード、スクリプト、リソースを作成します
5. **F5キー**でゲームを実行

### プロンプト例

```
このシーンでシューティングゲームを作って
```

```
宇宙サバイバルゲームを作成してください
```

```
2D横スクロールアクションゲームを作って
```

詳細は`PROMPT_EXAMPLES.md`を参照してください。

## 📋 必要なファイル一覧

プラグインの動作に必要なファイル：

### 🔴 必須ファイル（これがないと動作しません）

```
addons/ai_godot_assistant/
├── plugin.cfg                    # プラグイン定義
├── plugin.gd                     # プラグインメインスクリプト
├── ai_controller.gd              # AI通信制御
├── godot_operator.gd             # Godot操作実行
└── ui/
    ├── ai_dock.tscn              # UIシーン
    └── ai_dock.gd                # UIスクリプト
```

### 🟡 推奨ファイル（設定やドキュメント）

```
addons/ai_godot_assistant/
├── config.cfg.example            # 設定ファイルの例
├── README.md                     # プラグイン説明
├── PROMPT_EXAMPLES.md            # プロンプト例集
└── INSTALL.md                    # このファイル
```

### 🟢 自動生成ファイル（プラグイン実行時に作成）

```
addons/ai_godot_assistant/
└── config.cfg                    # APIキー設定（自動生成）
```

## 🔧 トラブルシューティング

### パネルが表示されない

1. プラグインが有効化されているか確認
2. Godotエディタを再起動
3. エラーログを確認（出力タブ）

### APIエラー (コード 404)

- モデル名が正しいか確認
- 推奨: **Gemini 2.5 Flash** または **Gemini 2.5 Pro**
- カスタムモデル名を試す場合は注意

### APIキーが保存されない

1. `config.cfg`が作成されているか確認
2. ファイルのパーミッションを確認
3. 手動で`config.cfg`を作成

## 📚 対応モデル（2025年12月版）

動作確認済み：
- ✅ **Gemini 2.5 Pro**（高性能、推奨）
- ✅ **Gemini 2.5 Flash**（高速、デフォルト）
- ✅ **Gemini 2.0 Flash**（実験版）
- ✅ **Gemini 1.5 Pro**（安定版）
- ✅ **Gemini 1.5 Flash**（安定版）

## 🎉 完了！

インストールが完了しました！AIを使ってゲーム開発を楽しんでください！

質問や問題がある場合は、READMEまたはPROMPT_EXAMPLES.mdを参照してください。

---

**作成日**: 2025年12月4日  
**対応バージョン**: Godot 4.x  
**必要なAPI**: Google Gemini API


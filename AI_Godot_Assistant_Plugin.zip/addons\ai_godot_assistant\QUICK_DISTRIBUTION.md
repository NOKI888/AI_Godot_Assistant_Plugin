# 🚀 クイック配布ガイド

## 最速で配布パッケージを作る

### 方法1: PowerShellスクリプト（自動）

プロジェクトルートで実行：

```powershell
.\create_distribution.ps1
```

→ `AI_Godot_Assistant_Plugin.zip`が作成されます

### 方法2: 手動（3ステップ）

#### 1. フォルダをコピー

```
addons/ai_godot_assistant/
```

このフォルダを**そのまま**コピー

#### 2. config.cfgを削除

**重要**: `addons/ai_godot_assistant/config.cfg`を削除してください
（APIキーが含まれるため）

`config.cfg.example`は残してください

#### 3. ZIPに圧縮

`addons/`フォルダを右クリック → 「送る」 → 「圧縮（ZIP形式）フォルダー」

完了！

## 📋 配布パッケージに含めるもの

✅ **含める**：
- `addons/ai_godot_assistant/` フォルダ全体
- すべての`.gd`ファイル
- すべての`.tscn`ファイル
- `plugin.cfg`
- `config.cfg.example`
- README、INSTALL、PROMPT_EXAMPLES

❌ **含めない**：
- `config.cfg`（APIキーが含まれる！）
- プロジェクト固有のスクリプト（`player.gd`等）

## 📦 受け取った人のインストール

1. ZIPを解凍
2. `addons/ai_godot_assistant`をGodotプロジェクトの`addons/`にコピー
3. Godotで「プラグイン」から有効化
4. APIキーを設定

詳細は`INSTALL.md`参照

---

**これだけ！簡単でしょ？** 🎉


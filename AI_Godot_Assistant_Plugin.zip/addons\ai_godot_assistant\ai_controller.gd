@tool
extends Node
class_name AIController

const GodotOperator = preload("res://addons/ai_godot_assistant/godot_operator.gd")

signal response_received(response: String)
signal error_occurred(error: String)

# 利用可能なモデルのリスト（2025年12月時点、有料ティアで確認済み）
const AVAILABLE_MODELS = {
	"Gemini 3 Pro": "gemini-3-pro",
	"Gemini 2.5 Pro": "gemini-2.5-pro",
	"Gemini 2.5 Pro Exp": "gemini-2.5-pro-exp",
	"Gemini 2.5 Flash": "gemini-2.5-flash",
	"Gemini 2.5 Flash Lite": "gemini-2.5-flash-lite",
	"Gemini 2.0 Flash": "gemini-2.0-flash",
	"Gemini 2.0 Flash Lite": "gemini-2.0-flash-lite",
	"Gemini 2.0 Flash Exp": "gemini-2.0-flash-exp",
	"Gemini 1.5 Pro": "gemini-1.5-pro",
	"Gemini 1.5 Flash": "gemini-1.5-flash",
	"Gemini 1.5 Flash-8B": "gemini-1.5-flash-8b"
}

const API_BASE_URL = "https://generativelanguage.googleapis.com/v1/models/"
# Gemini 3はv1betaを試す必要があるかもしれません
const API_BASE_URL_BETA = "https://generativelanguage.googleapis.com/v1beta/models/"

# Gemini 3について:
# Google AI Studioには「gemini-3-pro」が表示されますが、
# API名は異なる可能性があります（gemini-exp-*, gemini-3.0-pro等）
# カスタムモデル入力で以下を試してください:
# - gemini-3.0-pro
# - gemini-3.0-flash
# - gemini-exp-1121
# - gemini-exp-1206
# - gemini-2.0-flash-thinking-exp-1219

var api_key: String = ""
var selected_model: String = "gemini-2.5-flash"  # デフォルトモデル（スクリーンショット確認済み）
var http_request: HTTPRequest
var godot_operator

func _ready() -> void:
	# HTTPRequestノードの作成
	http_request = HTTPRequest.new()
	add_child(http_request)
	http_request.request_completed.connect(_on_request_completed)
	
	# GodotOperatorの初期化
	godot_operator = GodotOperator.new()
	add_child(godot_operator)
	
	# APIキーの読み込み
	load_api_key()

func load_api_key() -> void:
	var config_path = "res://addons/ai_godot_assistant/config.cfg"
	var config = ConfigFile.new()
	var err = config.load(config_path)
	
	if err == OK:
		api_key = config.get_value("api", "gemini_api_key", "")
		selected_model = config.get_value("api", "selected_model", "gemini-2.0-flash-exp")
		if api_key.is_empty():
			print("警告: Gemini APIキーが設定されていません")
	else:
		print("config.cfgが見つかりません。新しく作成してください。")

func save_api_key(new_api_key: String) -> void:
	var config_path = "res://addons/ai_godot_assistant/config.cfg"
	var config = ConfigFile.new()
	config.load(config_path)  # 既存の設定を読み込む
	config.set_value("api", "gemini_api_key", new_api_key)
	config.save(config_path)
	api_key = new_api_key

func save_model_selection(model: String) -> void:
	var config_path = "res://addons/ai_godot_assistant/config.cfg"
	var config = ConfigFile.new()
	config.load(config_path)  # 既存の設定を読み込む
	config.set_value("api", "selected_model", model)
	config.save(config_path)
	selected_model = model
	print("[AI Controller] モデルを変更しました: ", model)

func send_prompt(prompt: String, context: Dictionary = {}) -> void:
	print("[AI Controller] send_prompt() が呼ばれました")
	print("[AI Controller] APIキーの長さ: ", api_key.length())
	
	if api_key.is_empty():
		error_occurred.emit("APIキーが設定されていません")
		return
	
	# コンテキスト情報を含む完全なプロンプトを構築
	var full_prompt = _build_prompt_with_context(prompt, context)
	
	# リクエストボディの構築
	var body = {
		"contents": [{
			"parts": [{
				"text": full_prompt
			}]
		}]
	}
	
	var json_body = JSON.stringify(body)
	
	# gemini-3やgemini-2.5で始まるモデルはv1betaを試す
	var base_url = API_BASE_URL
	if selected_model.begins_with("gemini-3") or selected_model.begins_with("gemini-2.5"):
		base_url = API_BASE_URL_BETA
		print("[AI Controller] 新しいモデル検出: v1beta APIを使用します")
	
	var url = base_url + selected_model + ":generateContent?key=" + api_key
	
	print("[AI Controller] 使用モデル: ", selected_model)
	print("[AI Controller] APIバージョン: ", "v1beta" if base_url == API_BASE_URL_BETA else "v1")
	print("[AI Controller] エンドポイント: ", url.left(80), "...")
	print("[AI Controller] リクエストボディサイズ: ", json_body.length(), " bytes")
	
	var headers = [
		"Content-Type: application/json"
	]
	
	var error = http_request.request(url, headers, HTTPClient.METHOD_POST, json_body)
	
	if error != OK:
		error_occurred.emit("HTTPリクエストの送信に失敗しました: " + str(error))
	else:
		print("[AI Controller] リクエストを送信しました")

func _build_prompt_with_context(prompt: String, context: Dictionary) -> String:
	var scene_root_name = context.get("scene_root", "Root")
	var scene_tree_info = context.get("scene_tree", "")
	var scene_type = "3D" if scene_root_name.contains("3D") or scene_root_name.contains("Node3D") else "2D"
	
	var system_prompt = """あなたはGodot 4.x エンジンの専門家AIアシスタントです。
Godot公式ドキュメント（https://docs.godotengine.org/ja/4.x/）の内容を熟知しており、
ベストプラクティスに従ってコードを生成します。

参考資料:
- Godot 4.x チュートリアル: https://docs.godotengine.org/ja/4.x/getting_started/introduction/introduction_to_godot.html
- GDScriptリファレンス: https://docs.godotengine.org/ja/4.x/tutorials/scripting/gdscript/
- 2D/3Dゲーム開発: https://docs.godotengine.org/ja/4.x/getting_started/first_2d_game/
- CharacterBody2D/3D: https://docs.godotengine.org/ja/4.x/classes/class_characterbody2d.html

【最重要1】ユーザーの要求を創造的に実装すること:
  - ユーザーが指定したテーマ、雰囲気、キャラクターの特徴を尊重する
  - 形状、色、サイズ、配置を要求に合わせて自由に決定する
  - 複数のMeshを組み合わせて複雑な形状を作ることを恐れない
  - Polyhavenからテーマに合ったHDRIやアセットを選択する
  - 単純すぎる実装を避け、ユーザーの期待を超える創造的な実装を目指す

【最重要2】子ノードを参照する際の絶対ルール:
  CREATE_NODE|X|Y|Parent で作成した場合
  ↓
  その後のすべてのコマンドで「Parent/Y」を使用！
  
  例:
  CREATE_NODE|MeshInstance3D|GroundMesh|Ground
  SET_RESOURCE|Ground/GroundMesh|mesh|BoxMesh|...  ← 「Ground/」必須！
  SET_PROPERTY|Ground/GroundMesh|position|...  ← 「Ground/」必須！
  
  親パスなしで参照すると「ノードが見つかりません」エラーになります！

ルート: """ + scene_root_name + """

使用可能なコマンド:
1. CREATE_NODE: 新しいノードを作成
   形式: CREATE_NODE|ノードタイプ|ノード名|親ノードパス
   例: CREATE_NODE|Sprite2D|PlayerSprite|Player

2. DELETE_NODE: ノードを削除
   形式: DELETE_NODE|ノードパス

3. SET_PROPERTY: ノードのプロパティを設定
   形式: SET_PROPERTY|ノードパス|プロパティ名|値
   例: SET_PROPERTY|Player/Camera|enabled|true （子ノードは親パスを含める）

4. ADD_SCRIPT: ノードにスクリプトをアタッチ
   形式: ADD_SCRIPT|ノードパス|スクリプトパス
   例: ADD_SCRIPT|Player|res://player.gd

5. CREATE_SCRIPT: 新しいスクリプトを作成
   形式: CREATE_SCRIPT|スクリプトパス|スクリプト内容
   【超重要】必ずCREATE_SCRIPTを実行してから、次の行でADD_SCRIPTを実行すること！
   
   正しい順序の例:
   CREATE_SCRIPT|res://player.gd|extends CharacterBody3D\\n\\n...
   ADD_SCRIPT|Player|res://player.gd  ← 前の行でスクリプトを作成した後！
   
   改行: \\n、タブ: \\t、バッククォート禁止

【シューティングゲーム等で動的にノードを生成する場合】:
   - preload("res://xxx.tscn")は使用しないこと！（.tscnファイルは存在しない）
   - 代わりに、既存のノード（例: Bullet、Enemy）を取得して複製する方法を使用：
   
   【シューティングゲーム等で動的生成する場合】:
   - テンプレートノードを画面外（visible=false）に配置
   - duplicate()で複製して使用
   - Godot公式ドキュメントのパターンに従う
   - シンプルで確実に動作するコードを優先
   
   3. Enemyノードのセットアップ:
      CREATE_NODE|CharacterBody2D|Enemy|.  ← ルートの直下に作成
      SET_PROPERTY|Enemy|position|Vector2(0,-2000)  ← 画面外に配置
      SET_PROPERTY|Enemy|visible|false  ← 非表示にしておく
   
   4. MainGameスクリプトでの敵スポーン:
   ```gdscript
   func spawn_enemy():
       var enemy_template = get_node_or_null("Enemy")
       if enemy_template:
           var enemy = enemy_template.duplicate()
           add_child(enemy)
           enemy.position = Vector2(randf_range(-300, 300), -300)
           enemy.visible = true
   ```
   
   【重要ルール】:
   - テンプレートノードは必ず visible=false に設定
   - 複製後は必ず visible=true に設定
   - get_node()ではなく get_node_or_null() を使用（エラー回避）
   - Playerから見てBulletは兄弟ノード → get_parent().get_node()
   - MainGameから見てEnemyは子ノード → get_node()
   
   【重要】スクリプト命名ルール：
   - 2Dゲームと3Dゲームでは必ず異なるスクリプト名を使用すること！
   - シーンの種類に応じて命名：
     * 3Dゲーム: res://player_3d.gd, res://enemy_3d.gd など
     * 2Dゲーム: res://player_2d.gd, res://enemy_2d.gd など
   - または現在のシーン名を含める: res://main_player.gd, res://platformer_player.gd など
   - 絶対に同じ res://player.gd を複数のシーンタイプで使わないこと！
   
   スクリプト例:
   - CharacterBody3D/2Dの基本スクリプトはGodot公式ドキュメントのテンプレートに従ってください
   - シンプルで確実に動作するコードを優先してください
   - 複雑な処理は避け、基本的な動作から始めてください

6. SET_RESOURCE: リソースプロパティを設定
   形式: SET_RESOURCE|ノードパス|プロパティ名|リソースタイプ|パラメータ
   
   【超重要】子ノードの場合は必ず完全パスを使用！
   - ✓ 正しい: SET_RESOURCE|Ground/GroundMesh|mesh|BoxMesh|size=Vector3(40,2,40)
   - ✗ 間違い: SET_RESOURCE|GroundMesh|mesh|BoxMesh|...  （見つからないエラー！）
   
   ルール: CREATE_NODEで親を指定したら、SET_RESOURCEでも同じ完全パスを使う！
   例:
   CREATE_NODE|MeshInstance3D|PlayerMesh|Player
   SET_RESOURCE|Player/PlayerMesh|mesh|CapsuleMesh|radius=0.5,height=2.0  ← 「Player/」を付ける！

7. SETUP_POLYHAVEN_HDRI: PolyhavenからHDRIをダウンロードしてWorldEnvironmentに適用（全自動）
   形式: SETUP_POLYHAVEN_HDRI|WorldEnvironmentノードパス|HDRI名|解像度
   
   テーマ別HDRI:
   - 宇宙: kloppenheim_06_puresky, studio_small_05（暗い空間）
   - 屋外: industrial_sunset_puresky, sunflowers_puresky
   - 都市: urban_street_01, evening_road_01
   
   例: SETUP_POLYHAVEN_HDRI|WorldEnvironment|kloppenheim_06_puresky|2k

8. DOWNLOAD_POLYHAVEN: Polyhavenから3Dモデルやテクスチャをダウンロード（手動適用）
   形式: DOWNLOAD_POLYHAVEN|model|モデル名|1k
   例: DOWNLOAD_POLYHAVEN|model|potted_plant|1k
   注: ダウンロード後、手動でシーンにインポートする必要があります

【3Dゲーム作成の基本ルール】:
- CollisionShape3D: 必ずSET_RESOURCEでshapeを設定
- MeshInstance3D: 必ずSET_RESOURCEでmeshを設定（サイズと色を指定）
- Camera3D: current=true、適切な位置と角度を設定
- WorldEnvironmentとDirectionalLight3Dを追加

【ビジュアル実装の原則】:
- Polyhavenから適切なHDRIを選択（SETUP_POLYHAVEN_HDRI使用）
- 複雑な形状は複数のMeshを組み合わせる（Node3Dで親グループ化）
- modulateプロパティで色を設定（Color(r,g,b,a)）
- SphereMesh、BoxMesh、CapsuleMesh、CylinderMesh等を創造的に使用
- サイズ、色、配置を要求に合わせて自由に決定

【物理システムの必須設定】:
- すべての物理ノードにcollision_layerとcollision_maskを設定すること
- 原則: 各オブジェクトタイプは異なるレイヤーに配置し、衝突すべき相手のレイヤーをマスクに設定
- 例の構造（数値は自由に決定）:
  * 地面/床: 特定のレイヤーに配置、プレイヤーがそのレイヤーと衝突するようマスク設定
  * プレイヤー: 別のレイヤーに配置、地面・敵と衝突するようマスク設定
  * 敵: さらに別のレイヤー、地面・プレイヤーと衝突
  * 弾: 独自のレイヤー、敵とのみ衝突
- 壁抜け・床抜けを防ぐため、必ずcollision設定を行うこと

【2Dゲーム作成の基本ルール】:
- 座標系: 原点(0,0)を中心に配置、カメラがプレイヤーを追従
- Camera2D: enabled=true（「current」ではない！）
- CollisionShape2D: 必ずSET_RESOURCEでshapeを設定
- Sprite2Dまたは ColorRectで視認性を確保
- 【物理設定】2Dでも collision_layer と collision_mask を設定（3Dと同じ原則）
- Godot公式ドキュメントのベストプラクティスに従う

【Godot 4.x API要点】:
- move_and_slide(): 引数なし
- 入力: ui_left, ui_right, ui_up, ui_down, ui_accept, ui_cancel, ui_select
- 未使用パラメータには_プレフィックス
- 改行=\\n、タブ=\\t、バッククォート禁止

現在のシーン情報:
ルートノード名: """ + scene_root_name + """
"""
	
	if context.has("scene_tree"):
		system_prompt += "\n【現在のシーンツリー】:\n" + str(context["scene_tree"])
		system_prompt += "\n重要: 上記のノードが既に存在しています。修正や追加の際は既存ノードを考慮してください。"
	if context.has("selected_node"):
		system_prompt += "\n選択中のノード: " + str(context["selected_node"])
	
	system_prompt += "\n\n【ユーザーの要求】: " + prompt + "\n"
	system_prompt += "※ユーザーの要求を正確に実装してください。テーマ、敵の種類、攻撃方法、背景の雰囲気を反映すること！\n\n"
	system_prompt += """
【超重要】すべてのコマンドで子ノードは完全パスを使用：
   
   例: CREATE_NODE|MeshInstance3D|PlayerMesh|Player で作成した場合
   - ✓ SET_PROPERTY|Player/PlayerMesh|position|...  ← 完全パス
   - ✓ SET_RESOURCE|Player/PlayerMesh|mesh|...  ← 完全パス
   - ✗ SET_PROPERTY|PlayerMesh|...  ← エラー！
   - ✗ SET_RESOURCE|PlayerMesh|...  ← エラー！
   
   CREATE_NODEで指定した親パスを、その後のすべてのコマンドで使用すること！

【必須ルール】:
1. パスは相対パス（/root/を使わない）
2. スクリプト名はシーン固有（例: """ + scene_root_name.to_lower() + """_player.gd、または player_2d.gd/player_3d.gd）
3. コマンド順序: CREATE_SCRIPT → ADD_SCRIPT （先に作成してからアタッチ）
5. Godot公式ドキュメントのベストプラクティスに従う
6. シンプルで確実に動作するコードを書く
7. 【推奨】よりリアルな3Dゲームを作る場合、Polyhavenから高品質アセットをダウンロード
   例: DOWNLOAD_POLYHAVEN|hdri|industrial_sunset_puresky|2k
   注: ダウンロード後はURLが表示されるので、手動でダウンロードして使用

上記のコマンド形式で、実行すべき操作を1行ずつ返してください。説明不要。"""
	
	return system_prompt

func _on_request_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS:
		error_occurred.emit("HTTPリクエストが失敗しました: " + str(result))
		return
	
	var body_text = body.get_string_from_utf8()
	print("[AI Controller] レスポンスコード: ", response_code)
	print("[AI Controller] レスポンスボディ: ", body_text)
	
	if response_code != 200:
		# エラーメッセージを解析
		var json = JSON.new()
		var parse_result = json.parse(body_text)
		var error_message = "APIエラー (コード " + str(response_code) + ")"
		
		if parse_result == OK and json.data is Dictionary:
			if json.data.has("error"):
				var error_data = json.data["error"]
				if error_data is Dictionary and error_data.has("message"):
					error_message += "\n詳細: " + error_data["message"]
		
		error_occurred.emit(error_message)
		return
	
	var json_parser = JSON.new()
	var parse_result = json_parser.parse(body_text)
	
	if parse_result != OK:
		error_occurred.emit("JSONのパースに失敗しました")
		return
	
	var response = json_parser.data
	
	if response.has("candidates") and response["candidates"].size() > 0:
		var candidate = response["candidates"][0]
		if candidate.has("content") and candidate["content"].has("parts"):
			var parts = candidate["content"]["parts"]
			if parts.size() > 0 and parts[0].has("text"):
				var ai_response = parts[0]["text"]
				response_received.emit(ai_response)
				
				# AIの応答を解析して実行
				_execute_ai_commands(ai_response)
				return
	
	error_occurred.emit("予期しないレスポンス形式です")

func _execute_ai_commands(commands_text: String) -> void:
	var lines = commands_text.split("\n")
	
	for line in lines:
		line = line.strip_edges()
		if line.is_empty() or line.begins_with("#") or line.begins_with("//"):
			continue
		
		var parts = line.split("|")
		if parts.size() == 0:
			continue
		
		var command = parts[0].strip_edges()
		
		match command:
			"CREATE_NODE":
				if parts.size() >= 4:
					godot_operator.create_node(parts[1], parts[2], parts[3])
			"DELETE_NODE":
				if parts.size() >= 2:
					godot_operator.delete_node(parts[1])
			"SET_PROPERTY":
				if parts.size() >= 4:
					godot_operator.set_node_property(parts[1], parts[2], parts[3])
			"ADD_SCRIPT":
				if parts.size() >= 3:
					godot_operator.add_script_to_node(parts[1], parts[2])
			"CREATE_SCRIPT":
				if parts.size() >= 3:
					var script_content = "|".join(parts.slice(2))
					godot_operator.create_script(parts[1], script_content)
			"SET_RESOURCE":
				if parts.size() >= 4:
					print("[AI Controller] SET_RESOURCEコマンド解析:")
					print("  parts.size() = ", parts.size())
					for i in range(parts.size()):
						print("  parts[", i, "] = '", parts[i], "'")
					
					var resource_params = parts[4] if parts.size() >= 5 else ""
					print("  渡すパラメータ: '", resource_params, "'")
					
					godot_operator.set_node_resource(parts[1], parts[2], parts[3], resource_params)
			"SETUP_POLYHAVEN_HDRI":
				if parts.size() >= 4:
					var world_env_path = parts[1].strip_edges()
					var hdri_name = parts[2].strip_edges()
					var resolution = parts[3].strip_edges()
					print("[AI Controller] Polyhaven HDRI完全セットアップ: ", world_env_path, " / ", hdri_name, " / ", resolution)
					godot_operator.setup_polyhaven_hdri(world_env_path, hdri_name, resolution)
			"DOWNLOAD_POLYHAVEN":
				if parts.size() >= 3:
					var asset_type = parts[1].strip_edges()
					var asset_name = parts[2].strip_edges()
					var resolution = parts[3].strip_edges() if parts.size() >= 4 else "1k"
					print("[AI Controller] Polyhavenダウンロード: ", asset_type, " / ", asset_name, " / ", resolution)
					godot_operator.download_polyhaven_asset(asset_type, asset_name, resolution)

func get_current_scene_context() -> Dictionary:
	return godot_operator.get_scene_context()


@tool
extends Node
class_name GodotOperator

signal operation_completed(message: String)
signal operation_failed(error: String)

var editor_interface: EditorInterface
var polyhaven_http: HTTPRequest  # Polyhaven API用
var polyhaven_download_http: HTTPRequest  # 実際のファイルダウンロード用
var hdri_apply_timer: Timer  # HDRI適用用タイマー
var hdri_apply_attempts: int = 0  # 適用試行回数

func _ready() -> void:
	# Polyhaven API用HTTPRequestを作成
	polyhaven_http = HTTPRequest.new()
	add_child(polyhaven_http)
	polyhaven_http.request_completed.connect(_on_polyhaven_api_completed)
	
	# 実際のファイルダウンロード用HTTPRequestを作成
	polyhaven_download_http = HTTPRequest.new()
	add_child(polyhaven_download_http)
	polyhaven_download_http.request_completed.connect(_on_polyhaven_file_downloaded)
	
	# HDRI適用用タイマーを作成
	hdri_apply_timer = Timer.new()
	add_child(hdri_apply_timer)
	hdri_apply_timer.wait_time = 0.5
	hdri_apply_timer.timeout.connect(_on_hdri_apply_timer_timeout)

func set_editor_interface(ei: EditorInterface) -> void:
	editor_interface = ei

func _normalize_path(path: String, scene_root: Node) -> String:
	# /root/ で始まるパスを処理
	if path.begins_with("/root/"):
		path = path.substr(6)  # "/root/" を削除
	
	# シーンルート名で始まる場合、それを削除
	if path.begins_with(scene_root.name + "/"):
		path = path.substr(scene_root.name.length() + 1)
	elif path == scene_root.name:
		path = "."
	
	# 空のパスは "." に
	if path.is_empty():
		path = "."
	
	return path

func get_scene_context() -> Dictionary:
	var context = {}
	
	if not editor_interface:
		return context
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if edited_scene:
		context["scene_root"] = edited_scene.name
		context["scene_tree"] = _get_tree_structure(edited_scene)
	
	var selection = editor_interface.get_selection()
	if selection:
		var selected_nodes = selection.get_selected_nodes()
		if selected_nodes.size() > 0:
			context["selected_node"] = selected_nodes[0].get_path()
	
	return context

func _get_tree_structure(node: Node, indent: int = 0) -> String:
	var result = "  ".repeat(indent) + "- " + node.name + " (" + node.get_class() + ")\n"
	
	for child in node.get_children():
		result += _get_tree_structure(child, indent + 1)
	
	return result

func create_node(node_type: String, node_name: String, parent_path: String) -> void:
	if not editor_interface:
		operation_failed.emit("エディタインターフェースが利用できません")
		return
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if not edited_scene:
		operation_failed.emit("編集中のシーンがありません")
		return
	
	# パスを正規化（/root/を削除、ルートノード名で始まるパスを相対パスに変換）
	var normalized_path = _normalize_path(parent_path, edited_scene)
	
	# 親ノードを取得
	var parent_node: Node
	if normalized_path == "/" or normalized_path.is_empty() or normalized_path == ".":
		parent_node = edited_scene
	else:
		parent_node = edited_scene.get_node_or_null(normalized_path)
	
	if not parent_node:
		operation_failed.emit("親ノードが見つかりません: " + parent_path + " (正規化後: " + normalized_path + ")")
		return
	
	# 新しいノードを作成
	var new_node: Node = null
	
	# ClassDBを使用してノードを作成
	if ClassDB.class_exists(node_type):
		new_node = ClassDB.instantiate(node_type)
	else:
		operation_failed.emit("不明なノードタイプです: " + node_type)
		return
	
	if new_node:
		new_node.name = node_name
		parent_node.add_child(new_node)
		new_node.owner = edited_scene
		
		operation_completed.emit("ノードを作成しました: " + node_name + " (" + node_type + ")")
	else:
		operation_failed.emit("ノードの作成に失敗しました: " + node_type)

func delete_node(node_path: String) -> void:
	if not editor_interface:
		operation_failed.emit("エディタインターフェースが利用できません")
		return
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if not edited_scene:
		operation_failed.emit("編集中のシーンがありません")
		return
	
	var normalized_path = _normalize_path(node_path, edited_scene)
	var node = edited_scene.get_node_or_null(normalized_path) if normalized_path != "." else edited_scene
	
	if not node:
		operation_failed.emit("ノードが見つかりません: " + node_path)
		return
	
	if node == edited_scene:
		operation_failed.emit("ルートノードは削除できません")
		return
	
	var node_name = node.name
	node.queue_free()
	operation_completed.emit("ノードを削除しました: " + node_name)

func set_node_property(node_path: String, property_name: String, value_str: String) -> void:
	if not editor_interface:
		operation_failed.emit("エディタインターフェースが利用できません")
		return
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if not edited_scene:
		operation_failed.emit("編集中のシーンがありません")
		return
	
	var normalized_path = _normalize_path(node_path, edited_scene)
	var node = edited_scene.get_node_or_null(normalized_path) if normalized_path != "." else edited_scene
	
	if not node:
		operation_failed.emit("ノードが見つかりません: " + node_path + " (正規化後: " + normalized_path + ")")
		return
	
	# 値を適切な型に変換
	var value = _parse_value(value_str)
	
	if node.get(property_name) != null or property_name in node:
		node.set(property_name, value)
		operation_completed.emit("プロパティを設定しました: " + property_name + " = " + str(value))
	else:
		operation_failed.emit("プロパティが見つかりません: " + property_name)

func _parse_value(value_str: String):
	value_str = value_str.strip_edges()
	
	# bool
	if value_str.to_lower() == "true":
		return true
	if value_str.to_lower() == "false":
		return false
	
	# 数値
	if value_str.is_valid_int():
		return value_str.to_int()
	if value_str.is_valid_float():
		return value_str.to_float()
	
	# Vector2
	if value_str.begins_with("Vector2(") and value_str.ends_with(")"):
		var content = value_str.substr(8, value_str.length() - 9)
		var parts = content.split(",")
		if parts.size() == 2:
			return Vector2(parts[0].to_float(), parts[1].to_float())
	
	# Vector3
	if value_str.begins_with("Vector3(") and value_str.ends_with(")"):
		var content = value_str.substr(8, value_str.length() - 9)
		var parts = content.split(",")
		if parts.size() == 3:
			return Vector3(parts[0].to_float(), parts[1].to_float(), parts[2].to_float())
	
	# Color
	if value_str.begins_with("Color(") and value_str.ends_with(")"):
		var content = value_str.substr(6, value_str.length() - 7)
		var parts = content.split(",")
		if parts.size() >= 3:
			var r = parts[0].to_float()
			var g = parts[1].to_float()
			var b = parts[2].to_float()
			var a = 1.0 if parts.size() < 4 else parts[3].to_float()
			return Color(r, g, b, a)
	
	# デフォルトは文字列として返す
	return value_str

func add_script_to_node(node_path: String, script_path: String) -> void:
	if not editor_interface:
		operation_failed.emit("エディタインターフェースが利用できません")
		return
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if not edited_scene:
		operation_failed.emit("編集中のシーンがありません")
		return
	
	var normalized_path = _normalize_path(node_path, edited_scene)
	var node = edited_scene.get_node_or_null(normalized_path) if normalized_path != "." else edited_scene
	
	if not node:
		operation_failed.emit("ノードが見つかりません: " + node_path)
		return
	
	if not FileAccess.file_exists(script_path):
		operation_failed.emit("スクリプトファイルが見つかりません: " + script_path)
		return
	
	var script = load(script_path)
	if script:
		node.set_script(script)
		operation_completed.emit("スクリプトをアタッチしました: " + script_path)
	else:
		operation_failed.emit("スクリプトの読み込みに失敗しました: " + script_path)

func create_script(script_path: String, script_content: String) -> void:
	# エスケープシーケンスを実際の文字に変換
	# まず、\\n と \\t を一時的なプレースホルダーに置換
	var temp_newline = "<<<NEWLINE>>>"
	var temp_tab = "<<<TAB>>>"
	
	# \\n（2つのバックスラッシュ+n）を見つけて置換
	script_content = script_content.replace("\\\\n", temp_newline)
	script_content = script_content.replace("\\\\t", temp_tab)
	
	# \\n が残っている場合も処理（エスケープが1つの場合）
	script_content = script_content.replace("\\n", temp_newline)
	script_content = script_content.replace("\\t", temp_tab)
	
	# プレースホルダーを実際の改行・タブに変換
	script_content = script_content.replace(temp_newline, "\n")
	script_content = script_content.replace(temp_tab, "\t")
	
	# 不要な文字を削除（Markdownコードブロックの名残など）
	script_content = script_content.strip_edges()  # 前後の空白を削除
	script_content = script_content.trim_suffix("`")  # 末尾のバッククォートを削除
	script_content = script_content.trim_suffix("```")  # Markdownコードブロックを削除
	script_content = script_content.trim_prefix("```")  # 先頭のMarkdownコードブロックを削除
	script_content = script_content.trim_prefix("gdscript")  # 言語指定を削除
	script_content = script_content.strip_edges()  # 再度空白削除
	
	print("[GodotOperator] === スクリプト作成 ===")
	print("パス: ", script_path)
	print("スクリプト内容（最初の200文字）:\n", script_content.left(200))
	print("総行数: ", script_content.count("\n") + 1)
	
	var file = FileAccess.open(script_path, FileAccess.WRITE)
	if file:
		file.store_string(script_content)
		file.close()
		operation_completed.emit("スクリプトを作成しました: " + script_path)
		
		# スクリプトをリロード
		if editor_interface:
			var filesystem = editor_interface.get_resource_filesystem()
			if filesystem:
				filesystem.scan()
	else:
		operation_failed.emit("スクリプトの作成に失敗しました: " + script_path)

func set_node_resource(node_path: String, property_name: String, resource_type: String, params: String = "") -> void:
	print("[GodotOperator] === set_node_resource開始 ===")
	print("  ノードパス: ", node_path)
	print("  プロパティ: ", property_name)
	print("  リソースタイプ: ", resource_type)
	print("  パラメータ: '", params, "'")
	
	if not editor_interface:
		operation_failed.emit("エディタインターフェースが利用できません")
		return
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if not edited_scene:
		operation_failed.emit("編集中のシーンがありません")
		return
	
	var normalized_path = _normalize_path(node_path, edited_scene)
	var node = edited_scene.get_node_or_null(normalized_path) if normalized_path != "." else edited_scene
	
	if not node:
		operation_failed.emit("ノードが見つかりません: " + node_path)
		return
	
	print("  ノード見つかりました: ", node.name)
	
	# リソースを作成
	var resource = null
	
	if ClassDB.class_exists(resource_type):
		resource = ClassDB.instantiate(resource_type)
		print("  リソース作成成功: ", resource_type)
	else:
		operation_failed.emit("不明なリソースタイプです: " + resource_type)
		return
	
	if not resource:
		operation_failed.emit("リソースの作成に失敗しました: " + resource_type)
		return
	
	# パラメータを解析して設定
	if not params.is_empty():
		print("  パラメータ適用開始...")
		_apply_resource_parameters(resource, params)
	else:
		print("  パラメータなし")
	
	# リソースをノードに設定
	if node.get(property_name) != null or property_name in node:
		node.set(property_name, resource)
		print("  リソース設定完了: ", property_name, " = ", resource)
		operation_completed.emit("リソースを設定しました: " + property_name + " = " + resource_type)
	else:
		operation_failed.emit("プロパティが見つかりません: " + property_name)
	
	print("[GodotOperator] === set_node_resource終了 ===")

func _apply_resource_parameters(resource: Resource, params: String) -> void:
	# パラメータ形式: "size=Vector3(1,2,1),color=Color(1,0,0)"
	# 括弧内のカンマを考慮した分割
	var param_pairs = _split_params(params)
	
	for pair in param_pairs:
		var kv = pair.split("=", false, 1)  # 最初の=のみで分割
		if kv.size() >= 2:
			var param_name = kv[0].strip_edges()
			var param_value_str = kv[1].strip_edges()
			var param_value = _parse_value(param_value_str)
			
			# プロパティ名のマッピング（Godot固有の名前に対応）
			var actual_param_name = param_name
			
			# BoxShape3Dの場合、sizeはextentsとして設定（extentsはサイズの半分）
			if resource is BoxShape3D and param_name == "size":
				actual_param_name = "size"  # Godot 4.xではsizeが正しい
			
			print("[GodotOperator] リソースパラメータ設定を試行: ", actual_param_name, " = ", param_value_str, " -> ", param_value)
			
			if resource.get(actual_param_name) != null or actual_param_name in resource:
				resource.set(actual_param_name, param_value)
				print("[GodotOperator] ✓ リソースパラメータを設定: ", actual_param_name, " = ", param_value)
			else:
				print("[GodotOperator] ✗ 警告: プロパティが見つかりません: ", actual_param_name, " (リソース: ", resource.get_class(), ")")

func _split_params(params: String) -> Array:
	# 括弧を考慮してパラメータを分割
	var result = []
	var current = ""
	var depth = 0
	
	for i in range(params.length()):
		var c = params[i]
		if c == '(':
			depth += 1
			current += c
		elif c == ')':
			depth -= 1
			current += c
		elif c == ',' and depth == 0:
			if not current.is_empty():
				result.append(current.strip_edges())
			current = ""
		else:
			current += c
	
	if not current.is_empty():
		result.append(current.strip_edges())
	
	return result

# ========================================
# Polyhaven API統合
# ========================================

var current_download_info = {}  # ダウンロード情報を保持
var pending_hdri_application = {}  # HDRI適用待ちの情報

func setup_polyhaven_hdri(world_env_path: String, hdri_name: String, resolution: String = "2k") -> void:
	print("[GodotOperator] === Polyhaven HDRI完全セットアップ ===")
	print("  WorldEnvironment: ", world_env_path)
	print("  HDRI名: ", hdri_name)
	print("  解像度: ", resolution)
	
	# HDRI適用待ち情報を保存
	pending_hdri_application = {
		"world_env_path": world_env_path,
		"hdri_name": hdri_name,
		"resolution": resolution
	}
	
	# HDRIをダウンロード
	download_polyhaven_asset("hdri", hdri_name, resolution)

func download_polyhaven_asset(asset_type: String, asset_name: String, resolution: String = "2k") -> void:
	print("[GodotOperator] Polyhavenアセットをダウンロード中...")
	print("  タイプ: ", asset_type)
	print("  名前: ", asset_name)
	print("  解像度: ", resolution)
	
	# Polyhaven API URL
	var api_url = "https://api.polyhaven.com/files/" + asset_name
	
	current_download_info = {
		"asset_type": asset_type,
		"asset_name": asset_name,
		"resolution": resolution
	}
	
	# APIからファイル情報を取得
	var error = polyhaven_http.request(api_url)
	
	if error != OK:
		operation_failed.emit("Polyhaven APIリクエスト失敗: " + str(error))
		return
	
	operation_completed.emit("Polyhavenアセット情報を取得中: " + asset_name)

func _on_polyhaven_api_completed(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS:
		operation_failed.emit("Polyhavenダウンロード失敗: " + str(result))
		return
	
	if response_code != 200:
		operation_failed.emit("Polyhaven APIエラー (コード " + str(response_code) + ")")
		return
	
	var json = JSON.new()
	var parse_result = json.parse(body.get_string_from_utf8())
	
	if parse_result != OK:
		operation_failed.emit("Polyhaven JSONパース失敗")
		return
	
	var files_data = json.data
	var asset_type = current_download_info.get("asset_type", "")
	var asset_name = current_download_info.get("asset_name", "")
	var resolution = current_download_info.get("resolution", "2k")
	
	print("[GodotOperator] Polyhavenファイルデータ取得成功")
	print("  利用可能なファイル: ", files_data.keys())
	
	# アセットタイプに応じて適切なファイルを選択
	var download_url = _select_polyhaven_file(files_data, asset_type, resolution)
	
	if download_url.is_empty():
		operation_failed.emit("適切なPolyhavenファイルが見つかりません")
		return
	
	print("[GodotOperator] ダウンロードURL: ", download_url)
	
	# ファイル拡張子を取得
	var file_extension = download_url.get_extension()
	
	# 保存先パスを決定
	var save_dir = "res://assets/polyhaven/"
	var save_path = save_dir + asset_name + "_" + resolution + "." + file_extension
	
	# assets/polyhavenフォルダが存在しない場合は作成
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(save_dir))
	
	# ダウンロード情報を更新
	current_download_info["download_url"] = download_url
	current_download_info["save_path"] = save_path
	
	operation_completed.emit("Polyhavenファイルをダウンロード中: " + asset_name + " → " + save_path)
	
	# 実際のファイルダウンロードを開始
	var error = polyhaven_download_http.request(download_url)
	
	if error != OK:
		operation_failed.emit("ファイルダウンロードリクエスト失敗: " + str(error))
		return

func _on_polyhaven_file_downloaded(result: int, response_code: int, headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS:
		operation_failed.emit("Polyhavenファイルダウンロード失敗: " + str(result))
		return
	
	if response_code != 200:
		operation_failed.emit("Polyhavenファイルダウンロードエラー (コード " + str(response_code) + ")")
		return
	
	var save_path = current_download_info.get("save_path", "")
	var asset_name = current_download_info.get("asset_name", "")
	
	if save_path.is_empty():
		operation_failed.emit("保存パスが不明です")
		return
	
	# ファイルを保存
	var file = FileAccess.open(save_path, FileAccess.WRITE)
	if file:
		file.store_buffer(body)
		file.close()
		
		print("[GodotOperator] ファイル保存完了: ", save_path)
		print("[GodotOperator] ファイルサイズ: ", body.size(), " bytes")
		
		# エディタのファイルシステムを更新
		if editor_interface:
			var filesystem = editor_interface.get_resource_filesystem()
			if filesystem:
				filesystem.scan()
				print("[GodotOperator] ファイルシステムを再スキャンしました")
		
		operation_completed.emit("✅ Polyhavenアセットをダウンロードしました: " + asset_name)
		operation_completed.emit("保存先: " + save_path)
		
		# HDRI適用待ちがある場合、自動的に適用
		if not pending_hdri_application.is_empty():
			print("[GodotOperator] HDRI適用待ちを検出、自動適用を開始...")
			var world_env_path = pending_hdri_application.get("world_env_path", "")
			
			if not world_env_path.is_empty():
				# HDRIファイルパスを保存
				pending_hdri_application["hdri_file_path"] = save_path
				
				# タイマーを使用してファイルインポート完了を待つ
				hdri_apply_attempts = 0
				hdri_apply_timer.start()
				print("[GodotOperator] タイマー開始: 0.5秒ごとにインポート状況をチェック")
			else:
				operation_completed.emit("ファイルシステムを確認してください。自動的にインポートされます。")
		else:
			operation_completed.emit("ファイルシステムを確認してください。自動的にインポートされます。")
	else:
		operation_failed.emit("ファイルの保存に失敗しました: " + save_path)

func _select_polyhaven_file(files_data: Dictionary, asset_type: String, resolution: String) -> String:
	# アセットタイプに応じて適切なファイルを選択
	
	if asset_type == "hdri":
		# HDRIの場合、exr形式を探す
		if files_data.has("hdri"):
			var hdri_data = files_data["hdri"]
			if hdri_data.has(resolution):
				var res_data = hdri_data[resolution]
				if res_data.has("exr"):
					return res_data["exr"]["url"] if res_data["exr"].has("url") else ""
	
	elif asset_type == "texture":
		# テクスチャの場合、jpg/png形式を探す
		if files_data.has("Diffuse") or files_data.has("diff"):
			var diff_key = "Diffuse" if files_data.has("Diffuse") else "diff"
			var diff_data = files_data[diff_key]
			if diff_data.has(resolution):
				var res_data = diff_data[resolution]
				if res_data.has("jpg"):
					return res_data["jpg"]["url"] if res_data["jpg"].has("url") else ""
	
	elif asset_type == "model":
		# 3Dモデルの場合、glb形式を探す
		if files_data.has("glb"):
			var glb_data = files_data["glb"]
			if glb_data.has(resolution):
				var res_data = glb_data[resolution]
				if res_data.has("url"):
					return res_data["url"]
	
	# フォールバック: 最初に見つかったURLを返す
	for key in files_data.keys():
		var data = files_data[key]
		if data is Dictionary:
			if data.has(resolution):
				var res_data = data[resolution]
				if res_data is Dictionary:
					for format_key in res_data.keys():
						if res_data[format_key] is Dictionary and res_data[format_key].has("url"):
							return res_data[format_key]["url"]
	
	return ""

func _on_hdri_apply_timer_timeout() -> void:
	hdri_apply_attempts += 1
	
	var hdri_file_path = pending_hdri_application.get("hdri_file_path", "")
	
	if hdri_file_path.is_empty():
		hdri_apply_timer.stop()
		return
	
	print("[GodotOperator] インポート確認中... (試行 ", hdri_apply_attempts, "/20)")
	
	# ファイルが読み込み可能かチェック
	var test_load = load(hdri_file_path)
	
	if test_load:
		# ファイルが読み込めた！
		print("[GodotOperator] ✅ ファイルインポート完了確認！")
		hdri_apply_timer.stop()
		
		var world_env_path = pending_hdri_application.get("world_env_path", "")
		apply_hdri_to_environment(world_env_path, hdri_file_path)
		
		pending_hdri_application = {}  # クリア
		hdri_apply_attempts = 0
		
	elif hdri_apply_attempts >= 20:
		# タイムアウト
		print("[GodotOperator] ❌ インポートタイムアウト")
		hdri_apply_timer.stop()
		operation_failed.emit("HDRIファイルのインポートがタイムアウトしました。")
		operation_failed.emit("ファイルシステムパネルで " + hdri_file_path + " を確認してください。")
		operation_failed.emit("手動でWorldEnvironmentに設定することも可能です。")
		pending_hdri_application = {}
		hdri_apply_attempts = 0

func apply_hdri_to_environment(world_env_path: String, hdri_file_path: String) -> void:
	print("[GodotOperator] === HDRI適用開始 ===")
	print("  WorldEnvironmentパス: ", world_env_path)
	print("  HDRIファイル: ", hdri_file_path)
	
	if not editor_interface:
		operation_failed.emit("エディタインターフェースが利用できません")
		return
	
	var edited_scene = editor_interface.get_edited_scene_root()
	if not edited_scene:
		operation_failed.emit("編集中のシーンがありません")
		return
	
	# WorldEnvironmentノードを取得
	var normalized_path = _normalize_path(world_env_path, edited_scene)
	var world_env = edited_scene.get_node_or_null(normalized_path) if normalized_path != "." else edited_scene
	
	if not world_env:
		operation_failed.emit("WorldEnvironmentノードが見つかりません: " + world_env_path)
		return
	
	if not world_env is WorldEnvironment:
		operation_failed.emit("指定されたノードはWorldEnvironmentではありません: " + world_env.get_class())
		return
	
	# HDRIファイルが存在するか確認
	if not FileAccess.file_exists(hdri_file_path):
		operation_failed.emit("HDRIファイルが見つかりません: " + hdri_file_path)
		return
	
	print("  WorldEnvironmentノード確認: OK")
	print("  HDRIファイル確認: OK")
	
	# Environmentリソースを作成
	var environment = Environment.new()
	
	# Skyを作成
	var sky = Sky.new()
	var sky_material = PanoramaSkyMaterial.new()
	
	# HDRIをロード
	print("  HDRIファイルを読み込み中...")
	var hdri_texture = load(hdri_file_path)
	if not hdri_texture:
		operation_failed.emit("HDRIファイルの読み込みに失敗しました: " + hdri_file_path)
		operation_failed.emit("ファイルが存在するか、正しくインポートされているか確認してください。")
		return
	
	print("  HDRIテクスチャ読み込み: OK")
	print("  テクスチャタイプ: ", hdri_texture.get_class())
	print("  テクスチャサイズ: ", hdri_texture.get_size() if hdri_texture.has_method("get_size") else "不明")
	
	# PanoramaSkyMaterialにHDRIを設定
	sky_material.panorama = hdri_texture
	print("  PanoramaSkyMaterialにパノラマ設定: OK")
	
	sky.sky_material = sky_material
	print("  Skyにマテリアル設定: OK")
	
	# Environmentの設定
	environment.background_mode = Environment.BG_SKY
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	print("  Environmentにスカイ設定: OK")
	
	# WorldEnvironmentに設定
	world_env.environment = environment
	print("  WorldEnvironmentに適用: OK")
	
	print("[GodotOperator] === HDRI適用完了 ===")
	operation_completed.emit("✅ HDRIを適用しました: " + hdri_file_path)
	operation_completed.emit("WorldEnvironment → Environment → Sky → PanoramaSkyMaterial → HDRI")
	operation_completed.emit("背景がリアルな環境マップに変更されました。F5で確認してください。")


@tool
extends EditorPlugin

const AIController = preload("res://addons/ai_godot_assistant/ai_controller.gd")
const GodotOperator = preload("res://addons/ai_godot_assistant/godot_operator.gd")

var dock_scene: Control
var ai_controller

func _enter_tree() -> void:
	print("[AI Godot Assistant] プラグイン初期化開始...")
	
	# AIコントローラーの初期化
	ai_controller = AIController.new()
	add_child(ai_controller)
	print("[AI Godot Assistant] AIControllerを作成しました")
	
	# _ready()を待つために、次のフレームでエディタインターフェースを設定
	await get_tree().process_frame
	
	# GodotOperatorにエディタインターフェースを設定
	if ai_controller.godot_operator:
		ai_controller.godot_operator.set_editor_interface(get_editor_interface())
		print("[AI Godot Assistant] エディタインターフェースを設定しました")
	else:
		print("[AI Godot Assistant] 警告: GodotOperatorが初期化されていません")
	
	# ドックシーンの読み込みと追加
	print("[AI Godot Assistant] UIシーンを読み込み中...")
	var ui_scene_path = "res://addons/ai_godot_assistant/ui/ai_dock.tscn"
	
	if not FileAccess.file_exists(ui_scene_path):
		push_error("[AI Godot Assistant] エラー: UIシーンファイルが見つかりません: " + ui_scene_path)
		return
	
	dock_scene = load(ui_scene_path).instantiate()
	if not dock_scene:
		push_error("[AI Godot Assistant] エラー: UIシーンのインスタンス化に失敗しました")
		return
	
	print("[AI Godot Assistant] UIシーンをインスタンス化しました")
	print("[AI Godot Assistant] UIシーンのサイズ: ", dock_scene.size)
	print("[AI Godot Assistant] UIシーンの可視性: ", dock_scene.visible)
	
	dock_scene.ai_controller = ai_controller
	
	# 明示的にサイズと可視性を設定
	dock_scene.custom_minimum_size = Vector2(300, 400)
	dock_scene.visible = true
	
	add_control_to_dock(DOCK_SLOT_RIGHT_UL, dock_scene)
	print("[AI Godot Assistant] ドックパネルを追加しました (位置: RIGHT_UL)")
	print("[AI Godot Assistant] 最終サイズ: ", dock_scene.size)
	
	print("[AI Godot Assistant] プラグインが有効化されました ✓")

func _exit_tree() -> void:
	# ドックの削除
	if dock_scene:
		remove_control_from_docks(dock_scene)
		dock_scene.queue_free()
	
	# AIコントローラーの削除
	if ai_controller:
		ai_controller.queue_free()
	
	print("AI Godot Assistant プラグインが無効化されました")


@tool
extends Control

const AIController = preload("res://addons/ai_godot_assistant/ai_controller.gd")

var ai_controller

@onready var prompt_input: TextEdit = $VBoxContainer/PromptInput
@onready var send_button: Button = $VBoxContainer/HBoxContainer/SendButton
@onready var clear_button: Button = $VBoxContainer/HBoxContainer/ClearButton
@onready var response_output: TextEdit = $VBoxContainer/ResponseOutput
@onready var api_key_input: LineEdit = $VBoxContainer/APIKeyContainer/APIKeyInput
@onready var save_api_key_button: Button = $VBoxContainer/APIKeyContainer/SaveButton
@onready var model_selector: OptionButton = $VBoxContainer/ModelContainer/ModelSelector
@onready var custom_model_input: LineEdit = $VBoxContainer/ModelContainer/CustomModelInput
@onready var use_custom_button: Button = $VBoxContainer/ModelContainer/UseCustomButton
@onready var status_label: Label = $VBoxContainer/StatusLabel

func _ready() -> void:
	print("[AI Dock] _ready() が呼ばれました")
	print("[AI Dock] パネルサイズ: ", size)
	print("[AI Dock] 可視性: ", visible)
	
	# ボタンの接続
	if send_button:
		send_button.pressed.connect(_on_send_button_pressed)
		print("[AI Dock] 送信ボタンを接続しました")
	if clear_button:
		clear_button.pressed.connect(_on_clear_button_pressed)
	if save_api_key_button:
		save_api_key_button.pressed.connect(_on_save_api_key_button_pressed)
	if use_custom_button:
		use_custom_button.pressed.connect(_on_use_custom_model_pressed)
	
	# モデル選択のドロップダウンを初期化
	if model_selector and ai_controller:
		_setup_model_selector()
	
	# AIコントローラーのシグナル接続
	if ai_controller:
		print("[AI Dock] AIコントローラーに接続します")
		ai_controller.response_received.connect(_on_response_received)
		ai_controller.error_occurred.connect(_on_error_occurred)
		
		# GodotOperatorのシグナル接続
		if ai_controller.godot_operator:
			ai_controller.godot_operator.operation_completed.connect(_on_operation_completed)
			ai_controller.godot_operator.operation_failed.connect(_on_operation_failed)
			print("[AI Dock] GodotOperatorに接続しました")
	else:
		print("[AI Dock] 警告: AIコントローラーがnullです")
	
	print("[AI Dock] 初期化完了")

func _setup_model_selector() -> void:
	model_selector.clear()
	
	var index = 0
	var selected_index = 0
	
	for model_name in AIController.AVAILABLE_MODELS.keys():
		model_selector.add_item(model_name)
		var model_id = AIController.AVAILABLE_MODELS[model_name]
		
		# 現在選択されているモデルを見つける
		if model_id == ai_controller.selected_model:
			selected_index = index
		
		index += 1
	
	model_selector.selected = selected_index
	model_selector.item_selected.connect(_on_model_selected)
	print("[AI Dock] モデルセレクタを初期化しました")

func _on_model_selected(index: int) -> void:
	var model_name = model_selector.get_item_text(index)
	var model_id = AIController.AVAILABLE_MODELS[model_name]
	
	if ai_controller:
		ai_controller.save_model_selection(model_id)
		_update_status("モデルを変更: " + model_name, false)

func _on_use_custom_model_pressed() -> void:
	var custom_model = custom_model_input.text.strip_edges()
	
	if custom_model.is_empty():
		_update_status("カスタムモデル名を入力してください", true)
		return
	
	if ai_controller:
		ai_controller.save_model_selection(custom_model)
		_update_status("カスタムモデルを設定: " + custom_model, false)
		response_output.text += "\n[情報] カスタムモデルを使用: " + custom_model + "\n"
		response_output.text += "※このモデルが存在しない場合、404エラーが発生します\n"
	else:
		_update_status("AIコントローラーが初期化されていません", true)

func _on_send_button_pressed() -> void:
	var prompt = prompt_input.text.strip_edges()
	
	if prompt.is_empty():
		_update_status("プロンプトを入力してください", true)
		return
	
	if not ai_controller:
		_update_status("AIコントローラーが初期化されていません", true)
		return
	
	_update_status("AIに送信中...", false)
	send_button.disabled = true
	
	# 現在のシーンコンテキストを取得
	var context = ai_controller.get_current_scene_context()
	
	# プロンプトを送信
	ai_controller.send_prompt(prompt, context)

func _on_clear_button_pressed() -> void:
	prompt_input.text = ""
	response_output.text = ""
	_update_status("クリアしました", false)

func _on_save_api_key_button_pressed() -> void:
	var api_key = api_key_input.text.strip_edges()
	
	if api_key.is_empty():
		_update_status("APIキーを入力してください", true)
		return
	
	if ai_controller:
		ai_controller.save_api_key(api_key)
		_update_status("APIキーを保存しました", false)
		api_key_input.secret = true
	else:
		_update_status("AIコントローラーが初期化されていません", true)

func _on_response_received(response: String) -> void:
	response_output.text += "\n=== AIの応答 ===\n" + response + "\n"
	
	# 完了メッセージと操作説明を追加
	response_output.text += "\n=== 🎮 ゲーム操作方法 ===\n"
	response_output.text += "F5キー: ゲームを実行\n"
	response_output.text += "Esc: ゲームを終了\n"
	response_output.text += "\n【ゲーム内操作】\n"
	response_output.text += "矢印キー↑↓←→: 移動\n"
	response_output.text += "Spaceキー: ジャンプ/発射\n"
	response_output.text += "\n【エディタ操作】\n"
	response_output.text += "Fキー: 選択ノードにフォーカス\n"
	response_output.text += "マウス中ボタン+ドラッグ: ビュー移動\n"
	response_output.text += "マウスホイール: ズーム\n\n"
	
	_update_status("応答を受信しました", false)
	send_button.disabled = false

func _on_error_occurred(error: String) -> void:
	response_output.text += "\n=== エラー ===\n" + error + "\n"
	_update_status("エラーが発生しました: " + error, true)
	send_button.disabled = false

func _on_operation_completed(message: String) -> void:
	response_output.text += "[操作完了] " + message + "\n"
	_update_status(message, false)

func _on_operation_failed(error: String) -> void:
	response_output.text += "[操作失敗] " + error + "\n"
	_update_status("操作失敗: " + error, true)

func _update_status(message: String, is_error: bool) -> void:
	if status_label:
		status_label.text = message
		if is_error:
			status_label.add_theme_color_override("font_color", Color.RED)
		else:
			status_label.add_theme_color_override("font_color", Color.WHITE)

